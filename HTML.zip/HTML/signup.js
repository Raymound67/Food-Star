document.getElementById('signupForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    let isValid = true;
    
    // Get form inputs
    const firstName = document.getElementById('firstName').value.trim();
    const lastName = document.getElementById('lastName').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();
    const confirmPassword = document.getElementById('confirmPassword').value.trim();
    
    // Validate first name
    if (firstName === "") {
        isValid = false;
        document.getElementById('firstNameError').style.display = 'block';
    } else {
        document.getElementById('firstNameError').style.display = 'none';
    }
    
    // Validate last name
    if (lastName === "") {
        isValid = false;
        document.getElementById('lastNameError').style.display = 'block';
    } else {
        document.getElementById('lastNameError').style.display = 'none';
    }
    
    // Validate email
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (email === "" || !emailPattern.test(email)) {
        isValid = false;
        document.getElementById('emailError').style.display = 'block';
    } else {
        document.getElementById('emailError').style.display = 'none';
    }
    
    // Validate password
    if (password === "") {
        isValid = false;
        document.getElementById('passwordError').style.display = 'block';
    } else {
        document.getElementById('passwordError').style.display = 'none';
    }
    
    // Validate confirm password
    if (confirmPassword === "" || confirmPassword !== password) {
        isValid = false;
        document.getElementById('confirmPasswordError').style.display = 'block';
    } else {
        document.getElementById('confirmPasswordError').style.display = 'none';
    }
    
    // Validated
    if (isValid) {
        alert('SignUp successfully!');
        window.location.href = 'login.html';
    }
});

document.querySelectorAll('.toggle-password').forEach(button => {
    button.addEventListener('click', function() {
        const input = this.parentElement.previousElementSibling;
        const icon = this.querySelector('i');
        if (input.type === 'password') {
            input.type = 'text';
            icon.classList.remove('bi-eye');
            icon.classList.add('bi-eye-slash');
        } else {
            input.type = 'password';
            icon.classList.remove('bi-eye-slash');
            icon.classList.add('bi-eye');
        }
    });
});
