document.addEventListener('DOMContentLoaded', () => {
// Navbar   
    const hamburger = document.getElementById('hamburger');
    const menu = document.getElementById('menu');
    const profileIcon = document.getElementById('profile-icon');
    const dropdownContent = document.getElementById('dropdown-content');

    hamburger.addEventListener('click', () => {
        menu.classList.toggle('show');
        document.body.classList.toggle('menu-open');
    });

    profileIcon.addEventListener('click', (event) => {
        event.stopPropagation();
        if (menu.classList.contains('show')) {
            menu.classList.remove('show');
            document.body.classList.remove('menu-open');
        }
        dropdownContent.classList.toggle('show');
    });

    document.addEventListener('click', (event) => {
        const isClickInside = hamburger.contains(event.target) || menu.contains(event.target) || profileIcon.contains(event.target);
        if (!isClickInside) {
            menu.classList.remove('show');
            document.body.classList.remove('menu-open');
            dropdownContent.classList.remove('show');
        }
    });

// Brand
    const carousel = document.querySelector('.brand-carousel');
    let isDown = false;
    let startX;
    let scrollLeft;

    carousel.addEventListener('mousedown', (e) => {
        isDown = false;
        carousel.classList.remove('active');
    });

    carousel.addEventListener('mouseleave', () => {
        isDown = false;
        carousel.classList.remove('active');
    });

    carousel.addEventListener('mouseup', () => {
        isDown = false;
        carousel.classList.remove('active');
    });

    carousel.addEventListener('mousemove', (e) => {
        if (!isDown) return;
        e.preventDefault();
        const x = e.pageX - carousel.offsetLeft;
        const walk = (x - startX) * 3;
        carousel.scrollLeft = scrollLeft - walk;
    });
});

// FAQs
function toggleAnswer(answerId) {
    var answer = document.getElementById(answerId);
    if (answer.style.display === "none" || answer.style.display === "") {
        answer.style.display = "block";
    } else {
        answer.style.display = "none";
    }
}

// Error Massage
document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    let isValid = true;
    
    // Get form inputs
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const message = document.getElementById('message').value.trim();
    
    // Validate name
    if (name === "") {
        isValid = false;
        document.getElementById('nameError').style.display = 'block';
    } else {
        document.getElementById('nameError').style.display = 'none';
    }
    
    // Validate email
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (email === "" || !emailPattern.test(email)) {
        isValid = false;
        document.getElementById('emailError').style.display = 'block';
    } else {
        document.getElementById('emailError').style.display = 'none';
    }
    
    // Validate message
    if (message === "") {
        isValid = false;
        document.getElementById('messageError').style.display = 'block';
    } else {
        document.getElementById('messageError').style.display = 'none';
    }
    
    // Validate Success
    if (isValid) {
        alert('Form submitted successfully!');
    }
});

// Scroll to top 
document.getElementById('scrollToTop').addEventListener('click', function() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});


